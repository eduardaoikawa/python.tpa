# -*- coding: utf-8 -*-

def main():
    print ("Olá mundo")

if __name__ == "__main__":
    main()