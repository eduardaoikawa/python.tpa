#c-*- config: utf-8 -*-

numero = float(input("Digite um número: "))

if numero % 2 == 0:
    print(f"O número {numero} é par ")

else:
    print(f"O número {numero} é impar ")

print("Final do programa!")