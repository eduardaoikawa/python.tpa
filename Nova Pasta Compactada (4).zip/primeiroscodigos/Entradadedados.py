#c-*- config: utf-8 -*-

numero1 = float(input("Digite o primeiro número:"))
numero2 = float(input("Digite o segundo número:"))

soma = numero1 + numero2 

print (f"A soma de {numero1} + {numero2} é = {soma}")
